#include <bits/stdc++.h>
using namespace std;

const double X[] = {0, 2, 5, 6, 8, 1, 7, 3};
const double Y[] = {0, 6, 2, 7, 3, 4, 6, 1};
const string NAMES = "WABCDEFG";

double dist(int a, int b) {
    return sqrt((X[a] - X[b]) * (X[a] - X[b]) + (Y[a] - Y[b]) * (Y[a] - Y[b]));
}

double cost(const vector<int> &r) {
    double total = dist(0, r[0]);
    for (size_t i = 0; i + 1 < r.size(); i++) total += dist(r[i], r[i + 1]);
    total += dist(r.back(), 0);
    return total;
}

string routeStr(const vector<int> &r) {
    string s = "W";
    for (int v : r) {
        s += " -> ";
        s += NAMES[v];
    }
    s += " -> W";
    return s;
}

vector<int> randomRoute(mt19937 &rng) {
    vector<int> r = {1, 2, 3, 4, 5, 6, 7};
    shuffle(r.begin(), r.end(), rng);
    return r;
}

int main() {
    mt19937 rng(random_device{}());
    uniform_real_distribution<double> uni(0.0, 1.0);
    uniform_int_distribution<int> pick(0, 6);
    cout << fixed << setprecision(4);

    double T = 100.0, alpha = 0.95, minT = 0.1;
    vector<int> cur = randomRoute(rng);
    double curCost = cost(cur);
    vector<int> best = cur;
    double bestCost = curCost;

    cout << "Initial route: " << routeStr(cur) << "\n";
    cout << "Initial cost: " << curCost << "\n\n";

    int iterations = 0;
    while (T >= minT) {
        iterations++;
        int i = pick(rng), j = pick(rng);
        while (j == i) j = pick(rng);
        vector<int> nb = cur;
        swap(nb[i], nb[j]);
        double nbCost = cost(nb);
        double dE = nbCost - curCost;
        bool accepted = false;
        if (dE < 0) {
            accepted = true;
        } else {
            double P = exp(-dE / T);
            double r = uni(rng);
            if (r < P) accepted = true;
        }
        if (accepted) {
            cur = nb;
            curCost = nbCost;
            if (curCost < bestCost) {
                bestCost = curCost;
                best = cur;
            }
        }
        cout << "Iter " << setw(3) << iterations << "  T = " << setw(8) << T
             << "  neighbour cost = " << nbCost << "  dE = " << setw(9) << dE
             << "  " << (accepted ? "ACCEPTED" : "REJECTED")
             << "  current cost = " << curCost << "\n";
        T = alpha * T;
    }

    cout << "\nBest route: " << routeStr(best) << "\n";
    cout << "Best cost: " << bestCost << "\n";
    cout << "Number of iterations: " << iterations << "\n";
    return 0;
}
