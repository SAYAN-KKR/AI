#include <bits/stdc++.h>
using namespace std;

const string START = "123#46758";
const string GOAL = "12345678#";

vector<string> neighbours(const string &s) {
    vector<string> res;
    int p = s.find('#');
    int r = p / 3, c = p % 3;
    int dr[] = {-1, 1, 0, 0};
    int dc[] = {0, 0, -1, 1};
    for (int k = 0; k < 4; k++) {
        int nr = r + dr[k], nc = c + dc[k];
        if (nr < 0 || nr > 2 || nc < 0 || nc > 2) continue;
        string t = s;
        swap(t[p], t[nr * 3 + nc]);
        res.push_back(t);
    }
    return res;
}

void printState(const string &s) {
    for (int i = 0; i < 9; i++) cout << s[i] << (i % 3 == 2 ? "\n" : " ");
}

void printPath(const map<string, string> &parent, const string &goal) {
    vector<string> path;
    for (string cur = goal; cur != ""; cur = parent.at(cur)) path.push_back(cur);
    reverse(path.begin(), path.end());
    for (size_t i = 0; i < path.size(); i++) {
        cout << "Step " << i << ":\n";
        printState(path[i]);
        cout << "\n";
    }
    cout << "Number of moves: " << path.size() - 1 << "\n";
}

int main() {
    map<string, string> parent;
    stack<string> st;
    st.push(START);
    parent[START] = "";
    set<string> visited;
    int expanded = 0;
    bool found = false;

    while (!st.empty()) {
        string cur = st.top();
        st.pop();
        if (visited.count(cur)) continue;
        visited.insert(cur);
        expanded++;
        if (cur == GOAL) {
            found = true;
            break;
        }
        vector<string> nb = neighbours(cur);
        for (int i = (int)nb.size() - 1; i >= 0; i--) {
            if (!visited.count(nb[i])) {
                parent[nb[i]] = cur;
                st.push(nb[i]);
            }
        }
    }

    if (!found) {
        cout << "No solution\n";
        return 0;
    }
    cout << "DFS\n\n";
    printPath(parent, GOAL);
    cout << "Nodes expanded: " << expanded << "\n";
    return 0;
}
