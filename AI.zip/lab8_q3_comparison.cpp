#include <bits/stdc++.h>
using namespace std;

const double X[] = {0, 2, 5, 6, 8, 1, 7, 3};
const double Y[] = {0, 6, 2, 7, 3, 4, 6, 1};
const string NAMES = "WABCDEFG";

double dist(int a, int b) {
    return sqrt((X[a] - X[b]) * (X[a] - X[b]) + (Y[a] - Y[b]) * (Y[a] - Y[b]));
}

double cost(const vector<int> &r) {
    double total = dist(0, r[0]);
    for (size_t i = 0; i + 1 < r.size(); i++) total += dist(r[i], r[i + 1]);
    total += dist(r.back(), 0);
    return total;
}

string routeStr(const vector<int> &r) {
    string s = "W";
    for (int v : r) {
        s += " -> ";
        s += NAMES[v];
    }
    s += " -> W";
    return s;
}

vector<int> randomRoute(mt19937 &rng) {
    vector<int> r = {1, 2, 3, 4, 5, 6, 7};
    shuffle(r.begin(), r.end(), rng);
    return r;
}

double hillClimb(vector<int> cur, int &iterations) {
    double curCost = cost(cur);
    iterations = 0;
    while (true) {
        iterations++;
        vector<int> bestNb;
        double bestCost = 1e18;
        for (int i = 0; i < 7; i++) {
            for (int j = i + 1; j < 7; j++) {
                vector<int> nb = cur;
                swap(nb[i], nb[j]);
                double c = cost(nb);
                if (c < bestCost) {
                    bestCost = c;
                    bestNb = nb;
                }
            }
        }
        if (bestCost < curCost - 1e-9) {
            cur = bestNb;
            curCost = bestCost;
        } else {
            break;
        }
    }
    return curCost;
}

double annealing(vector<int> cur, mt19937 &rng, int &iterations) {
    uniform_real_distribution<double> uni(0.0, 1.0);
    uniform_int_distribution<int> pick(0, 6);
    double T = 100.0, alpha = 0.95, minT = 0.1;
    double curCost = cost(cur);
    double bestCost = curCost;
    iterations = 0;
    while (T >= minT) {
        iterations++;
        int i = pick(rng), j = pick(rng);
        while (j == i) j = pick(rng);
        vector<int> nb = cur;
        swap(nb[i], nb[j]);
        double nbCost = cost(nb);
        double dE = nbCost - curCost;
        if (dE < 0 || uni(rng) < exp(-dE / T)) {
            cur = nb;
            curCost = nbCost;
            if (curCost < bestCost) bestCost = curCost;
        }
        T = alpha * T;
    }
    return bestCost;
}

int main() {
    mt19937 rng(random_device{}());
    cout << fixed << setprecision(4);

    const int RUNS = 5;
    double hcCost[RUNS], saCost[RUNS];
    int hcIt[RUNS], saIt[RUNS];

    cout << "Run  Initial route            HC Cost   SA Cost   HC Iter  SA Iter\n";
    for (int k = 0; k < RUNS; k++) {
        vector<int> start = randomRoute(rng);
        hcCost[k] = hillClimb(start, hcIt[k]);
        saCost[k] = annealing(start, rng, saIt[k]);
        string init;
        for (int v : start) init += NAMES[v];
        cout << setw(3) << k + 1 << "  " << setw(20) << init << "  " << setw(8) << hcCost[k]
             << "  " << setw(8) << saCost[k] << "  " << setw(7) << hcIt[k] << "  " << setw(7) << saIt[k] << "\n";
    }

    double hcBest = *min_element(hcCost, hcCost + RUNS), hcWorst = *max_element(hcCost, hcCost + RUNS);
    double saBest = *min_element(saCost, saCost + RUNS), saWorst = *max_element(saCost, saCost + RUNS);
    double hcAvg = 0, saAvg = 0, hcAvgIt = 0, saAvgIt = 0;
    for (int k = 0; k < RUNS; k++) {
        hcAvg += hcCost[k];
        saAvg += saCost[k];
        hcAvgIt += hcIt[k];
        saAvgIt += saIt[k];
    }
    hcAvg /= RUNS;
    saAvg /= RUNS;
    hcAvgIt /= RUNS;
    saAvgIt /= RUNS;

    cout << "\n                 Hill Climbing   Simulated Annealing\n";
    cout << "Best cost        " << setw(13) << hcBest << "   " << setw(19) << saBest << "\n";
    cout << "Worst cost       " << setw(13) << hcWorst << "   " << setw(19) << saWorst << "\n";
    cout << "Average cost     " << setw(13) << hcAvg << "   " << setw(19) << saAvg << "\n";
    cout << "Average iters    " << setw(13) << hcAvgIt << "   " << setw(19) << saAvgIt << "\n";
    return 0;
}
