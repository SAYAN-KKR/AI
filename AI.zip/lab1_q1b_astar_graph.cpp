#include <bits/stdc++.h>
using namespace std;

int main() {
    const int N = 6;
    const char name[] = "abcdef";
    int h[N] = {6, 2, 5, 6, 4, 0};
    vector<vector<pair<int, int>>> g(N);
    int edges[][3] = {{0,1,5},{0,3,3},{0,2,2},{2,1,2},{1,5,3},{2,5,6},{2,3,1},{2,4,2},{3,4,4},{4,5,4}};
    for (auto &e : edges) {
        g[e[0]].push_back({e[1], e[2]});
        g[e[1]].push_back({e[0], e[2]});
    }

    int src = 0, goal = 5;
    vector<int> best(N, INT_MAX), parent(N, -1);
    priority_queue<tuple<int, int, int>, vector<tuple<int, int, int>>, greater<tuple<int, int, int>>> pq;
    best[src] = 0;
    pq.push(make_tuple(h[src], 0, src));

    while (!pq.empty()) {
        int f, gc, u;
        tie(f, gc, u) = pq.top();
        pq.pop();
        if (gc > best[u]) continue;
        cout << "Expand " << name[u] << "  g=" << gc << " h=" << h[u] << " f=" << f << "\n";
        if (u == goal) break;
        for (auto &edge : g[u]) {
            int v = edge.first, w = edge.second;
            if (gc + w < best[v]) {
                best[v] = gc + w;
                parent[v] = u;
                pq.push(make_tuple(best[v] + h[v], best[v], v));
                cout << "  Push " << name[v] << "  g=" << best[v] << " h=" << h[v] << " f=" << best[v] + h[v] << "\n";
            }
        }
    }

    vector<int> path;
    for (int v = goal; v != -1; v = parent[v]) path.push_back(v);
    reverse(path.begin(), path.end());
    cout << "\nShortest path: ";
    for (size_t i = 0; i < path.size(); i++) {
        if (i) cout << " -> ";
        cout << name[path[i]];
    }
    cout << "\nCost: " << best[goal] << "\n";
    return 0;
}
