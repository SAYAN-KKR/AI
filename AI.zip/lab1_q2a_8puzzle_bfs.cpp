#include <bits/stdc++.h>
using namespace std;

const string START = "123#46758";
const string GOAL = "12345678#";

vector<string> neighbours(const string &s) {
    vector<string> res;
    int p = s.find('#');
    int r = p / 3, c = p % 3;
    int dr[] = {-1, 1, 0, 0};
    int dc[] = {0, 0, -1, 1};
    for (int k = 0; k < 4; k++) {
        int nr = r + dr[k], nc = c + dc[k];
        if (nr < 0 || nr > 2 || nc < 0 || nc > 2) continue;
        string t = s;
        swap(t[p], t[nr * 3 + nc]);
        res.push_back(t);
    }
    return res;
}

void printState(const string &s) {
    for (int i = 0; i < 9; i++) cout << s[i] << (i % 3 == 2 ? "\n" : " ");
}

void printPath(const map<string, string> &parent, const string &goal) {
    vector<string> path;
    for (string cur = goal; cur != ""; cur = parent.at(cur)) path.push_back(cur);
    reverse(path.begin(), path.end());
    for (size_t i = 0; i < path.size(); i++) {
        cout << "Step " << i << ":\n";
        printState(path[i]);
        cout << "\n";
    }
    cout << "Number of moves: " << path.size() - 1 << "\n";
}

int main() {
    map<string, string> parent;
    queue<string> q;
    q.push(START);
    parent[START] = "";
    int expanded = 0;
    bool found = false;

    while (!q.empty()) {
        string cur = q.front();
        q.pop();
        expanded++;
        if (cur == GOAL) {
            found = true;
            break;
        }
        for (const string &nx : neighbours(cur)) {
            if (!parent.count(nx)) {
                parent[nx] = cur;
                q.push(nx);
            }
        }
    }

    if (!found) {
        cout << "No solution\n";
        return 0;
    }
    cout << "BFS\n\n";
    printPath(parent, GOAL);
    cout << "Nodes expanded: " << expanded << "\n";
    return 0;
}
