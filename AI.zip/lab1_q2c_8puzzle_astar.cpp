#include <bits/stdc++.h>
using namespace std;

const string START = "123#46758";
const string GOAL = "12345678#";

vector<string> neighbours(const string &s) {
    vector<string> res;
    int p = s.find('#');
    int r = p / 3, c = p % 3;
    int dr[] = {-1, 1, 0, 0};
    int dc[] = {0, 0, -1, 1};
    for (int k = 0; k < 4; k++) {
        int nr = r + dr[k], nc = c + dc[k];
        if (nr < 0 || nr > 2 || nc < 0 || nc > 2) continue;
        string t = s;
        swap(t[p], t[nr * 3 + nc]);
        res.push_back(t);
    }
    return res;
}

void printState(const string &s) {
    for (int i = 0; i < 9; i++) cout << s[i] << (i % 3 == 2 ? "\n" : " ");
}

void printPath(const map<string, string> &parent, const string &goal) {
    vector<string> path;
    for (string cur = goal; cur != ""; cur = parent.at(cur)) path.push_back(cur);
    reverse(path.begin(), path.end());
    for (size_t i = 0; i < path.size(); i++) {
        cout << "Step " << i << ":\n";
        printState(path[i]);
        cout << "\n";
    }
    cout << "Number of moves: " << path.size() - 1 << "\n";
}

int heuristic(const string &s) {
    int cnt = 0;
    for (int i = 0; i < 9; i++)
        if (s[i] != '#' && s[i] != GOAL[i]) cnt++;
    return cnt;
}

int main() {
    map<string, string> parent;
    map<string, int> bestG;
    set<string> closed;
    priority_queue<tuple<int, int, int, string>, vector<tuple<int, int, int, string>>, greater<tuple<int, int, int, string>>> pq;
    int counter = 0;
    parent[START] = "";
    bestG[START] = 0;
    pq.push(make_tuple(heuristic(START), 0, counter++, START));
    int expanded = 0;
    bool found = false;

    while (!pq.empty()) {
        int f, g, id;
        string cur;
        tie(f, g, id, cur) = pq.top();
        pq.pop();
        if (closed.count(cur)) continue;
        closed.insert(cur);
        expanded++;
        cout << "Expand g=" << g << " h=" << heuristic(cur) << " f=" << f << "  " << cur << "\n";
        if (cur == GOAL) {
            found = true;
            break;
        }
        for (const string &nx : neighbours(cur)) {
            if (closed.count(nx)) continue;
            int ng = g + 1;
            if (!bestG.count(nx) || ng < bestG[nx]) {
                bestG[nx] = ng;
                parent[nx] = cur;
                pq.push(make_tuple(ng + heuristic(nx), ng, counter++, nx));
            }
        }
    }

    if (!found) {
        cout << "No solution\n";
        return 0;
    }
    cout << "\nA*\n\n";
    printPath(parent, GOAL);
    cout << "Nodes expanded: " << expanded << "\n";
    return 0;
}
