#include <bits/stdc++.h>
using namespace std;

int main() {
    const int N = 6;
    const char name[] = "abcdef";
    vector<vector<pair<int, int>>> g(N);
    int edges[][3] = {{0,1,5},{0,3,3},{0,2,2},{2,1,2},{1,5,3},{2,5,6},{2,3,1},{2,4,2},{3,4,4},{4,5,4}};
    for (auto &e : edges) {
        g[e[0]].push_back({e[1], e[2]});
        g[e[1]].push_back({e[0], e[2]});
    }

    int src = 0, goal = 5;
    vector<int> dist(N, INT_MAX), parent(N, -1);
    vector<bool> done(N, false);
    priority_queue<pair<int, int>, vector<pair<int, int>>, greater<pair<int, int>>> pq;
    dist[src] = 0;
    pq.push({0, src});

    while (!pq.empty()) {
        pair<int, int> top = pq.top();
        pq.pop();
        int d = top.first, u = top.second;
        if (done[u]) continue;
        done[u] = true;
        cout << "Expand " << name[u] << " with distance " << d << "\n";
        if (u == goal) break;
        for (auto &edge : g[u]) {
            int v = edge.first, w = edge.second;
            if (!done[v] && d + w < dist[v]) {
                dist[v] = d + w;
                parent[v] = u;
                pq.push({dist[v], v});
                cout << "  Update " << name[v] << " = " << dist[v] << " via " << name[u] << "\n";
            }
        }
    }

    vector<int> path;
    for (int v = goal; v != -1; v = parent[v]) path.push_back(v);
    reverse(path.begin(), path.end());
    cout << "\nShortest path: ";
    for (size_t i = 0; i < path.size(); i++) {
        if (i) cout << " -> ";
        cout << name[path[i]];
    }
    cout << "\nCost: " << dist[goal] << "\n";
    return 0;
}
