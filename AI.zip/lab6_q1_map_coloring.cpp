#include <bits/stdc++.h>
using namespace std;

const int N = 5;
const string VAR = "ABCDE";
const string COLOR[] = {"Red", "Green", "Blue"};
vector<int> adj[N];
int assignedCount, backtrackCount;

bool consistent(int v, int c, const vector<int> &col) {
    for (int u : adj[v])
        if (col[u] == c) return false;
    return true;
}

int legalCount(int v, const vector<int> &col) {
    int cnt = 0;
    for (int c = 0; c < 3; c++)
        if (consistent(v, c, col)) cnt++;
    return cnt;
}

bool solveSimple(vector<int> &col, int idx) {
    if (idx == N) return true;
    int v = idx;
    for (int c = 0; c < 3; c++) {
        cout << "  Try " << VAR[v] << " = " << COLOR[c];
        if (!consistent(v, c, col)) {
            cout << "  -> conflict\n";
            continue;
        }
        cout << "  -> ok\n";
        col[v] = c;
        assignedCount++;
        if (solveSimple(col, idx + 1)) return true;
        col[v] = -1;
        backtrackCount++;
        cout << "  Backtrack from " << VAR[v] << "\n";
    }
    return false;
}

bool solveMRV(vector<int> &col, int done) {
    if (done == N) return true;
    int v = -1, bestLegal = 100;
    for (int i = 0; i < N; i++) {
        if (col[i] != -1) continue;
        int l = legalCount(i, col);
        if (l < bestLegal) {
            bestLegal = l;
            v = i;
        }
    }
    cout << "  MRV picks " << VAR[v] << " (legal values = " << bestLegal << ")\n";
    for (int c = 0; c < 3; c++) {
        cout << "  Try " << VAR[v] << " = " << COLOR[c];
        if (!consistent(v, c, col)) {
            cout << "  -> conflict\n";
            continue;
        }
        cout << "  -> ok\n";
        col[v] = c;
        assignedCount++;
        if (solveMRV(col, done + 1)) return true;
        col[v] = -1;
        backtrackCount++;
        cout << "  Backtrack from " << VAR[v] << "\n";
    }
    return false;
}

void printSolution(const vector<int> &col) {
    for (int i = 0; i < N; i++) cout << "  " << VAR[i] << " = " << COLOR[col[i]] << "\n";
}

int main() {
    adj[0] = {1, 2};
    adj[1] = {0, 2, 3, 4};
    adj[2] = {0, 1, 4};
    adj[3] = {1, 4};
    adj[4] = {1, 2, 3};

    cout << "Variables: A, B, C, D, E\n";
    cout << "Domain of each variable: {Red, Green, Blue}\n";
    cout << "Constraints: A!=B, A!=C, B!=C, B!=D, B!=E, C!=E, D!=E\n\n";

    cout << "Backtracking search (order A, B, C, D, E)\n";
    vector<int> col(N, -1);
    assignedCount = 0;
    backtrackCount = 0;
    solveSimple(col, 0);
    cout << "Solution:\n";
    printSolution(col);
    int simpleAssign = assignedCount, simpleBack = backtrackCount;
    cout << "Assignments made: " << simpleAssign << ", backtracks: " << simpleBack << "\n\n";

    cout << "Backtracking search with MRV\n";
    col.assign(N, -1);
    assignedCount = 0;
    backtrackCount = 0;
    solveMRV(col, 0);
    cout << "Solution:\n";
    printSolution(col);
    cout << "Assignments made: " << assignedCount << ", backtracks: " << backtrackCount << "\n\n";

    cout << "Comparison\n";
    cout << "Ordinary backtracking: assignments = " << simpleAssign << ", backtracks = " << simpleBack << "\n";
    cout << "With MRV:              assignments = " << assignedCount << ", backtracks = " << backtrackCount << "\n";
    return 0;
}
