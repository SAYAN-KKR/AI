#include <bits/stdc++.h>
using namespace std;

const double X[] = {0, 2, 5, 6, 8, 1, 7, 3};
const double Y[] = {0, 6, 2, 7, 3, 4, 6, 1};
const string NAMES = "WABCDEFG";

double dist(int a, int b) {
    return sqrt((X[a] - X[b]) * (X[a] - X[b]) + (Y[a] - Y[b]) * (Y[a] - Y[b]));
}

double cost(const vector<int> &r) {
    double total = dist(0, r[0]);
    for (size_t i = 0; i + 1 < r.size(); i++) total += dist(r[i], r[i + 1]);
    total += dist(r.back(), 0);
    return total;
}

string routeStr(const vector<int> &r) {
    string s = "W";
    for (int v : r) {
        s += " -> ";
        s += NAMES[v];
    }
    s += " -> W";
    return s;
}

vector<int> randomRoute(mt19937 &rng) {
    vector<int> r = {1, 2, 3, 4, 5, 6, 7};
    shuffle(r.begin(), r.end(), rng);
    return r;
}

int main() {
    mt19937 rng(random_device{}());
    cout << fixed << setprecision(4);

    vector<int> cur = randomRoute(rng);
    double curCost = cost(cur);
    cout << "Initial route: " << routeStr(cur) << "\n";
    cout << "Initial cost: " << curCost << "\n\n";

    int iterations = 0;
    while (true) {
        iterations++;
        vector<int> bestNb;
        double bestCost = 1e18;
        for (int i = 0; i < 7; i++) {
            for (int j = i + 1; j < 7; j++) {
                vector<int> nb = cur;
                swap(nb[i], nb[j]);
                double c = cost(nb);
                if (c < bestCost) {
                    bestCost = c;
                    bestNb = nb;
                }
            }
        }
        if (bestCost < curCost - 1e-9) {
            cur = bestNb;
            curCost = bestCost;
            cout << "Iteration " << iterations << ": " << routeStr(cur) << "  cost = " << curCost << "\n";
        } else {
            cout << "Iteration " << iterations << ": no better neighbour found, stopping\n";
            break;
        }
    }

    cout << "\nFinal route: " << routeStr(cur) << "\n";
    cout << "Final cost: " << curCost << "\n";
    cout << "Number of iterations: " << iterations << "\n";
    return 0;
}
