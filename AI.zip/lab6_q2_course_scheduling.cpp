#include <bits/stdc++.h>
using namespace std;

const int N = 4;
const string NAME[] = {"AI", "DBMS", "OS", "CN"};
bool conflict[N][N];
int assignments, backtracks;

string setStr(const set<int> &s) {
    string r = "{";
    bool first = true;
    for (int x : s) {
        if (!first) r += ", ";
        r += to_string(x);
        first = false;
    }
    return r + "}";
}

void showDomains(const vector<set<int>> &dom, const vector<int> &val) {
    for (int i = 0; i < N; i++) {
        cout << "    " << setw(5) << NAME[i] << " : ";
        if (val[i] != 0) cout << "assigned " << val[i] << "\n";
        else cout << setStr(dom[i]) << "\n";
    }
}

bool consistentPlain(int v, int t, const vector<int> &val) {
    for (int u = 0; u < N; u++)
        if (conflict[v][u] && val[u] == t) return false;
    return true;
}

bool plainSolve(const vector<set<int>> &dom, vector<int> &val, int idx) {
    if (idx == N) return true;
    for (int t : dom[idx]) {
        cout << "  Try " << NAME[idx] << " = " << t;
        if (!consistentPlain(idx, t, val)) {
            cout << " -> conflict\n";
            continue;
        }
        cout << " -> ok\n";
        val[idx] = t;
        assignments++;
        if (plainSolve(dom, val, idx + 1)) return true;
        val[idx] = 0;
        backtracks++;
        cout << "  Backtrack from " << NAME[idx] << "\n";
    }
    return false;
}

bool solve(vector<set<int>> dom, vector<int> &val, int done, int step) {
    if (done == N) return true;
    int v = -1;
    size_t best = 100;
    for (int i = 0; i < N; i++) {
        if (val[i] != 0) continue;
        if (dom[i].size() < best) {
            best = dom[i].size();
            v = i;
        }
    }
    cout << "Step " << step << "\n";
    cout << "  1. Variable selected using MRV: " << NAME[v] << " (domain size " << best << ")\n";
    set<int> candidates = dom[v];
    for (int t : candidates) {
        cout << "  2. Value assigned: " << t << "\n";
        vector<set<int>> nd = dom;
        vector<int> nv = val;
        nv[v] = t;
        assignments++;
        bool wipeout = false;
        for (int u = 0; u < N; u++) {
            if (conflict[v][u] && nv[u] == 0) {
                nd[u].erase(t);
                if (nd[u].empty()) wipeout = true;
            }
        }
        cout << "  3. Updated domains after Forward Checking:\n";
        showDomains(nd, nv);
        if (wipeout) {
            backtracks++;
            cout << "  4. Backtracking required: YES (a domain became empty), undo " << NAME[v] << " = " << t << "\n\n";
            continue;
        }
        cout << "  4. Backtracking required: NO\n\n";
        if (solve(nd, nv, done + 1, step + 1)) {
            val = nv;
            return true;
        }
        backtracks++;
        cout << "  Backtracking: undo " << NAME[v] << " = " << t << " and try next value\n\n";
    }
    return false;
}

int main() {
    vector<set<int>> dom(N);
    dom[0] = {1, 2, 3};
    dom[1] = {1, 2, 4};
    dom[2] = {2, 3, 4};
    dom[3] = {1, 3, 4};

    conflict[0][1] = conflict[1][0] = true;
    conflict[0][2] = conflict[2][0] = true;
    conflict[1][3] = conflict[3][1] = true;
    conflict[2][3] = conflict[3][2] = true;

    cout << "Variables: AI, DBMS, OS, CN\n";
    cout << "Domains:\n";
    for (int i = 0; i < N; i++) cout << "  " << NAME[i] << " : " << setStr(dom[i]) << "\n";
    cout << "Constraints: AI!=DBMS, AI!=OS, DBMS!=CN, OS!=CN\n\n";

    cout << "Plain backtracking search (order AI, DBMS, OS, CN)\n";
    vector<int> val(N, 0);
    assignments = 0;
    backtracks = 0;
    plainSolve(dom, val, 0);
    cout << "Assignments made: " << assignments << ", backtracks: " << backtracks << "\n";
    for (int i = 0; i < N; i++) cout << "  " << NAME[i] << " -> slot " << val[i] << "\n";

    cout << "\nBacktracking with MRV and Forward Checking\n\n";
    val.assign(N, 0);
    assignments = 0;
    backtracks = 0;
    bool ok = solve(dom, val, 0, 1);
    if (!ok) {
        cout << "No valid timetable\n";
        return 0;
    }
    cout << "Assignments made: " << assignments << ", backtracks: " << backtracks << "\n";
    cout << "Final timetable:\n";
    for (int i = 0; i < N; i++) cout << "  " << NAME[i] << " -> slot " << val[i] << "\n";
    return 0;
}
